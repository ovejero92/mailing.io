import os
import yagmail
import time
import pandas as pd
import flet as ft
from flet import *

tu_nombre = TextField(label="Ingresa tu nombre")
tu_apellido = TextField(label="Ingresa tu apellido")
rol = TextField(label="Ingresa tu rol")
curso = TextField(label="Ingresa tu curso")
dia = TextField(label="Ingresa dia de clase")
horario = TextField(label="Ingresa horario")
fecha_inicio = TextField(label="Ingresa fecha de inicio")
link_discord = TextField(label="Ingresa link de discord")

def main(page: ft.Page):
    page.bgcolor = ft.colors.BROWN_100
    page.title = "Credenciales"
    t = ft.Text(value="Ingreso de email & Credenciales", color=colors.BROWN_900, size=38, )
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.controls.append(t)
    

    def button_clicked(e):
  
        page.update()
        if not tb1.value:
            tb1.error_text = "Porfavor competa el campo del email"
            page.update()
        elif not tb2.value:
            tb2.error_text = "Porfavor competa el campo de clave gmail"
            page.update()
        else:
            page.clean()
            SegundaInterfas()
    t = ft.Text()
    tb1 = ft.TextField(label="Ingrese su cuenta email", hint_text="ejemplo@bue.edu.ar", icon=ft.icons.MAIL)
    tb2 = ft.TextField(label="Ingrese su clave de gmail", hint_text="x35g rg53 if43 12o3",password=True,can_reveal_password=True,icon=ft.icons.LOCK)
    a = ft.TextButton('¿Como crear clave gmail?',url="https://support.google.com/mail/answer/185833?hl=es-419")
    b = ft.ElevatedButton(text="Entrar", on_click=button_clicked)
    
    page.add(tb1,tb2,a,b)
    def volver(e):
        page.update()
        page.clean()
        page.bgcolor = ft.colors.BROWN_100
        page.title = "Credenciales"
        t = ft.Text(value="Ingreso de email & Credenciales", color="white", size=38, )
        page.vertical_alignment = ft.MainAxisAlignment.CENTER
        page.controls.append(t)
        page.add(tb1,tb2,b)
        
    def SegundaInterfas():
        page.fonts = {
            "NotoEmoji": "NotoColorEmoji-Regular.ttf",
            "Roberto": "Roboto-Black.ttf"
            }
        page.title = "AutoMail"
        page.bgcolor = ft.colors.BROWN_100
        page.vertical_alignment = ft.MainAxisAlignment.START
        btn = ft.ElevatedButton(icon=ft.icons.ARROW_BACK,text=f"Usuario:{tb1.value}",on_click=volver)
        
        def save_excel_file_result(e):
            current_directory = os.getcwd()
            excel_folder = "excel"
            os.makedirs(os.path.join(current_directory, excel_folder), exist_ok=True)
            rows = []
            bd = pd.read_excel('excel/archivo_excel.xlsx')
            bd.columns = ['nombre','email','emailRes','estado']
            for nombre, email, emailRes ,send in zip(bd['nombre'], bd['email'], bd['emailRes'], bd['estado']):
                row = DataRow(
                        cells=[
                        DataCell(Text(nombre)),
                        DataCell(Text(email)),
                        DataCell(Text(emailRes)),
                        DataCell(Text(send))
                        ])
                rows.append(row)
            img_recolectar = Image(
                src="img/Recolectar.png",
                width=450,
                height=490,
                border_radius=10
            )
            img_recordar = Image(
                src="img/Recordar.png",
                width=450,
                height=490,
                border_radius=10
            )
            img_confirmacion = Image(
                src="img/confirmacion.png",
                width=450,
                height=490,
                border_radius=10
            )
            dlg = ft.AlertDialog(
                title=ft.Text("Planilla de exel"),
                bgcolor=colors.PINK_50,
                content= DataTable(
                columns= [
                DataColumn(Text('Nombre')),
                DataColumn(Text('Email')),
                DataColumn(Text('Email responsable')),
                DataColumn(Text('Estado'))
                ],
                rows= rows,
                ))
            dlg_recolectar = AlertDialog(
                title= Text("plantilla recolectar documentacion"),
                bgcolor=colors.PINK_50,
                content= img_recolectar
            )
            dlg_recordar = AlertDialog(
                title= Text("Plantilla recordatorio documentación"),
                bgcolor=colors.PINK_50,
                content=img_recordar
            )
            dlg_confirmacion = AlertDialog(
                title= Text("Pantilla confirmación + discord"),
                bgcolor=colors.PINK_50,
                content=img_confirmacion
            )
            def open_dlg(e):
                page.dialog = dlg
                dlg.open = True
                page.update()
            def open_dlg_recolectar(e):
                page.dialog = dlg_recolectar
                dlg_recolectar.open = True
                page.update()
            def open_dlg_recordar(e):
                page.dialog = dlg_recordar
                dlg_recordar.open = True
                page.update()
            def open_dlg_confirmacion(e):
                page.dialog = dlg_confirmacion
                dlg_confirmacion.open = True
                page.update()
            def enviar_recolectar(e):
                def enviar():
                    for nombre, email, emailRes in zip(bd['nombre'],bd['email'],bd['emailRes']):
                        html=  f'<div style="color: rgb(80, 0, 80);"><div style="color: rgb(34, 34, 34);"><div style="font-size: 12.8px;"><p style="text-align: center;font-size: 12.8px;"><span style="color: rgb(0, 0, 0);font-size: 11pt;"><span style="font-size: 11pt;"><span style="border: none;"><img src="https://lh7-us.googleusercontent.com/2GkD14BDbU7Om16xXygRY_Itkbtp2mDHQmknjM7FYXD_NSOCqfOFt4P9ZcYNQUAMcaULNTGMVKVxuZRjyiKVK5xXkihOQEVd6xZjfkCPeyZ2g8lm3bqbjc79SygcTOJk2IURmlSE3StxumE_-cp_suI" width="602" height="145"></span></span><br></span></p><p style="text-align: center;font-size: 12.8px;"><span style="color: rgb(0, 0, 0);font-size: 11pt;">&iexcl;Hola {nombre}!</span></p><p style="text-align: center;font-size: 12.8px;"><span style="color: rgb(0, 0, 0);font-size: 11pt;">&iexcl;Te damos la bienvenida a Aprend&eacute; Programando!&nbsp;</span><strong><span style="color: rgb(0, 0, 0);font-size: 11pt;"><img alt="🚀" src="https://fonts.gstatic.com/s/e/notoemoji/15.0/1f680/32.png"></span></strong></p><p style="text-align: center;font-size: 12.8px;"><span style="color: rgb(0, 0, 0);font-size: 11pt;"><img alt="🙋" src="https://fonts.gstatic.com/s/e/notoemoji/15.0/1f64b/32.png">&nbsp;Soy {tu_nombre.value}</span><span style="color: rgb(0, 0, 0);font-size: 11pt;">&nbsp;y voy a ser tu {rol.value}</span><span style="color: rgb(0, 0, 0);font-size: 11pt;">&nbsp;durante el curso.&nbsp;</span></p><p style="text-align: center;font-size: 12.8px;"><span style="color: rgb(0, 0, 0);font-size: 11pt;">&iexcl;Estoy muy contento</span><span style="color: rgb(0, 0, 0);font-size: 11pt;">&nbsp;de que seas parte del programa!&nbsp;</span></p><p style="text-align: center;font-size: 12.8px;"><span style="color: rgb(0, 0, 0);font-size: 11pt;">Para confirmar tu vacante del curso de {curso.value},</span><strong><span style="color: rgb(255, 0, 0);font-size: 11pt;">&nbsp;</span></strong><span style="color: rgb(0, 0, 0);font-size: 11pt;">los d&iacute;as {dia.value},</span><strong><span style="color: rgb(255, 0, 0);font-size: 11pt;">&nbsp;</span></strong><span style="color: rgb(0, 0, 0);font-size: 11pt;">de {horario.value}</span></span><strong><span style="color: rgb(255, 0, 0);font-size: 11pt;">&nbsp;</span></strong><span style="color: rgb(0, 0, 0);font-size: 11pt;"><img alt="🚀" src="https://fonts.gstatic.com/s/e/notoemoji/15.0/1f680/32.png">&nbsp;es </span><strong><span style="color: rgb(0, 0, 0);font-size: 11pt;">muy importante</span></strong><span style="color: rgb(0, 0, 0);font-size: 11pt;">&nbsp;que nos envies respondiendo a este correo:</span></p><div style="text-align: center;"><span style="font-size: 12.8px;"><br></span></div><ul style="font-size: 12.8px;"><li style="list-style-type: disc;color: rgb(0, 0, 0);font-size: 11pt;"><p style="text-align: center;"><span style="font-size: 11pt;">Foto del DNI del alumno/a (frente y dorso).</span></p></li><li style="list-style-type: disc;color: rgb(0, 0, 0);font-size: 11pt;"><div style="text-align: center;"><span style="font-size: 11pt;">Autorizaci&oacute;n de participaci&oacute;n y difusi&oacute;n de imagen firmada.&nbsp;</span><a href="https://drive.google.com/file/d/1pO7PT7Fy6YD41hc2VkfXXfOmDSmFDZQu/view?usp=drive_link" target="_blank" style="color: rgb(17, 85, 204);font-size: 11pt;"><span style="font-size: 11pt;">DESCARGALA HACIENDO CLICK AC&Aacute;.</span></a></div><div style="text-align: center;"><a href="https://drive.google.com/file/d/1pO7PT7Fy6YD41hc2VkfXXfOmDSmFDZQu/view?usp=drive_link" target="_blank" style="color: rgb(17, 85, 204);"><br></a></div><span style="font-size: 11pt;"><div style="text-align: center;"><span style="font-size: 11pt;">Record&aacute; que podes declarar que NO aceptan la difusi&oacute;n de imagen,</span><strong><span style="font-size: 11pt;">&nbsp;pero la autorizaci&oacute;n debe estar completa y firmada.&nbsp;</span></strong></div></span><p><br></p></li></ul><p style="font-size: 12.8px;"><span style="color: rgb(0, 0, 0);font-size: 11pt;">Si necesitas</span><strong><span style="color: rgb(0, 0, 0);font-size: 11pt;">&nbsp;firmar digitalmente la autorizaci&oacute;n</span></strong><span style="color: rgb(0, 0, 0);font-size: 11pt;">, pod&eacute;s utilizar la siguiente p&aacute;gina web:&nbsp;</span><a href="https://www.ilovepdf.com/es/firmar-pdf" target="_blank" style="color: rgb(17, 85, 204);"><span style="font-size: 11pt;">https://www.ilovepdf.com/<wbr>es/firmar-pdf</span></a><span style="color: rgb(0, 0, 0);font-size: 11pt;">.&nbsp;</span><span style="color: rgb(0, 0, 0);font-size: 11pt;">Record&aacute; que la&nbsp;</span><strong><span style="color: rgb(0, 0, 0);font-size: 11pt;">firma debe ser manuscrita</span></strong><span style="color: rgb(0, 0, 0);font-size: 11pt;">, es decir, escrita o garabateada a mano.</span></p><p style="font-size: 12.8px; background: rgb(213,214,19);background:radial-gradient(circle, rgba(213,214,19,0.8827906162464986) 12%, rgba(112,108,12,1) 79%); text-align: center;border-radius: 20px;"><strong><span style="color: rgb(0, 0, 0);font-size: 11pt;"><span><img  alt="⚠️" src="https://fonts.gstatic.com/s/e/notoemoji/15.0/26a0_fe0f/32.png"></span>Una vez enviada la documentaci&oacute;n, confirmaremos que la recibimos y te enviaremos los datos de acceso a Discord para que estemos en contacto antes de comenzar y durante la cursada.</span></strong><span style="color: rgb(0, 0, 0);font-size: 11pt;"><br><br></span></p><p style="font-size: 12.8px;text-align:center;"><span style="color: rgb(0, 0, 0);font-size: 11pt;"><span style="border: none;"><img alt="📆" src="https://lh7-us.googleusercontent.com/tDA_VlnX4AlopEkwqYAVZIxsCGHKyUedsDoBPfDmztsnq_GDWH9HzPkCYaGTD4h3WL8s9xn4VGS_KMvArBnd9jGl9ApQW8w8mnJvmVCDF44U3UiLJpoBDPc-5dCxH902E1wLqfDLcElQ4PFzMUCBHC0" width="17" height="17"></span></span><span style="color: rgb(0, 0, 0);font-size: 11pt;">&nbsp;</span><span style="color: rgb(0, 0, 0);font-size: 11pt;">La fecha de inicio de clases es &nbsp;{fecha_inicio.value}</span></p><div style="text-align:center;"><strong><span style="color: rgb(0, 0, 0);font-size: 11pt;">Si no vas a sumarte, por favor avisanos, as&iacute; podemos ofrecer esa vacante a otra persona. <img alt="🙌" src="https://fonts.gstatic.com/s/e/notoemoji/15.0/1f64c/32.png"></span></strong></div></div></div></div></div><p>--</p><div><div><div style="text-align: start;color: rgb(34, 34, 34);background-color: rgb(255, 255, 255);font-size: small;"><br></div><div style="text-align: start;color: rgb(34, 34, 34);background-color: rgb(255, 255, 255);font-size: small;"><strong><img width="96" height="31" src="https://ci3.googleusercontent.com/mail-sig/AIorK4wTa9xs-F8lNN0rtQlQZz9zT7Fy4tyJw11JFiLolXbD43-TOdy4vIS646WAToLBk4UaLYNWhjo"><br></strong></div><div style="text-align: start;color: rgb(34, 34, 34);background-color: rgb(255, 255, 255);font-size: small;"><strong>{tu_nombre.value} {tu_apellido.value}</strong></div><div style="text-align: start;color: rgb(34, 34, 34);background-color: rgb(255, 255, 255);font-size: small;">{rol.value} | Aprende Programando&nbsp;</div><div style="text-align: start;color: rgb(34, 34, 34);background-color: rgb(255, 255, 255);font-size: small;"><span style="color: rgb(0, 0, 0);font-size: 12.8px;">Agencia de Aprendizaje a lo Largo de la Vida</span><span style="color: rgb(0, 0, 0);font-size: 12.8px;">&nbsp;|</span></div><div style="text-align: start;color: rgb(34, 34, 34);background-color: rgb(255, 255, 255);font-size: small;">Ministerio de Educaci&oacute;n - GCABA | Calle 10 y Perette. Piso 5. 5125.</div><div style="text-align: start;color: rgb(34, 34, 34);background-color: rgb(255, 255, 255);font-size: small;"><div style="color: rgb(34, 34, 34);"><div style="color: rgb(80, 0, 80);"><div><div style="color: rgb(34, 34, 34);"><div><div style="font-size: 12.8px;"><br></div></div></div></div></div></div></div></div></div>'
                        yag = yagmail.SMTP(user=f'{tb1.value}',password=f'{tb2.value}')
                        destinos = [email, emailRes]
                        asunto = f'💪 {nombre} TE DAMOS LA BIENVENIDA | Aprendé Programando 🚀'
                        yag.send(destinos,asunto,html)
                        time.sleep(3)
                        bd['estado'] = 'enviado'
                    bd.to_excel('excel/archivo_excel.xlsx', index=False)
                    snd = Container(
                            Text('Enviado ✓'),
                            padding=13,
                            border_radius=10,
                            bgcolor= colors.ORANGE_100
                            )
                    page.add(Row([snd,ElevatedButton('Otro',on_click=button_clicked)]))
                    page.update()
                enviar()
            def confirm_doc(e):
                page.add(
                    Row(
                        wrap=True,controls=[
                        Container(
                            content= tu_nombre,
                            margin=10,
                            padding=3,
                            alignment=ft.alignment.center,
                            bgcolor=ft.colors.ORANGE_100,
                            width=350,
                            height=60,
                            border_radius=10,),
                        Container(
                            content= tu_apellido,
                            margin=10,
                            padding=3,
                            alignment=ft.alignment.center,
                            bgcolor=ft.colors.ORANGE_100,
                            width=350,
                            height=60,
                            border_radius=10,),
                        Container(
                            content= rol,
                            margin=10,
                            padding=3,
                            alignment=ft.alignment.center,
                            bgcolor=ft.colors.ORANGE_100,
                            width=350,
                            height=60,
                            border_radius=10,),
                        Container(
                            content=curso,
                            margin=10,
                            padding=3,
                            alignment=ft.alignment.center,
                            bgcolor=ft.colors.ORANGE_100,
                            width=350,
                            height=60,
                            border_radius=10,),
                        Container(
                            content= dia,
                            margin=10,
                            padding=3,
                            alignment=ft.alignment.center,
                            bgcolor=ft.colors.ORANGE_100,
                            width=350,
                            height=60,
                            border_radius=10,),
                        Container(
                            content=horario,
                            margin=10,
                            padding=3,
                            alignment=ft.alignment.center,
                            bgcolor=ft.colors.ORANGE_100,
                            width=350,
                            height=60,
                            border_radius=10,),
                        Container(
                            content=fecha_inicio,
                            margin=10,
                            padding=3,
                            alignment=ft.alignment.center,
                            bgcolor=ft.colors.ORANGE_100,
                            width=350,
                            height=60,
                            border_radius=10,),
                    ]),
                    ElevatedButton('Enviar',on_click=enviar_recolectar),
                )
                page.update()
            def enviar_recordar(e):
                def enviar():
                    for nombre, email, emailRes in zip(bd['nombre'],bd['email'],bd['emailRes']):
                        html=  f'<div style="color: rgb(80, 0, 80);"><div style="color: rgb(34, 34, 34);"><div style="font-size: 12.8px;"><p style="text-align: center;"><span style="font-size:11pt;"><span style="border:none;"><img src="https://lh7-us.googleusercontent.com/AGgIkvhlagD48U36daLD8n81Uc5JCQc6FCHCAiLX4h7WCuFpXkoODEgAN-1bugYkXtOtMh9QTYRBw151eb3GHuB8q0S7DcdGxK7Azig7BIT_dVzS_grLYQo-eLuPdiSGwlWpGkoUK2Hc2LUCL9SZzcI" width="602" height="145"></span></span></p><br><p style="text-align: center;"><span style="font-size:11pt;">&iexcl;Hola {nombre}! &iquest;C&oacute;mo est&aacute;s?&nbsp;</span></p><p style="text-align: center;"><span style="font-size:11pt;">Te escribo porque no enviaste tu documentaci&oacute;n para comenzar el {curso.value}</span><span style="color:#ff0000;font-size:11pt;">&nbsp;</span><span style="color: rgb(0, 0, 0); font-size: 11pt;">los {dia.value}</span><span style="color:#ff0000;font-size:11pt;">&nbsp;</span><span style="color: rgb(0, 0, 0); font-size: 11pt;">de {horario.value} hs.</span></p><p style="text-align: center;"><br></p><p><span style="font-size:11pt;">Te recuerdo que para guardar tu lugar ten&eacute;s que enviar:&nbsp;</span></p><ul><li style="list-style-type:disc;font-size:11pt;"><p><span style="font-size:11pt;">Foto del DNI del alumno/a (frente y dorso).</span></p></li><li style="list-style-type:disc;font-size:11pt;"><p><a href="https://drive.google.com/file/d/118IiimN2KSDxF12xPgOXjepzieax-6pC/view?usp=drive_link"><u><span style="color:#1155cc;font-size:11pt;">Autorizaci&oacute;n de participaci&oacute;n</span></u></a><span style="font-size:11pt;">&nbsp;y&nbsp;</span><a href="https://drive.google.com/file/d/1DOZT1-9UDxVur699X4bgEkZCBKbZiT4k/view?usp=drive_link"><u><span style="color:#1155cc;font-size:11pt;">difusi&oacute;n de imagen</span></u></a><span style="font-size:11pt;">&nbsp;firmada. DESCARGALA HACIENDO CLICK AC&Aacute;.<br><br></span></p></li></ul><p><span style="font-size:11pt;">Record&aacute; que podes declarar que NO aceptan la difusi&oacute;n de imagen,&nbsp;</span><strong><u><span style="font-size:11pt;">pero la autorizaci&oacute;n debe estar completa y firmada.&nbsp;</span></u></strong></p><p><span style="font-size:11pt;">Si necesitas</span><strong><span style="font-size:11pt;">&nbsp;firmar digitalmente la autorizaci&oacute;n</span></strong><span style="font-size:11pt;">, pod&eacute;s utilizar la siguiente p&aacute;gina web:&nbsp;</span><a href="https://www.ilovepdf.com/es/firmar-pdf"><u><span style="color:#1155cc;font-size:11pt;">https://www.ilovepdf.com/es/firmar-pdf</span></u></a><span style="font-size:11pt;">.&nbsp;</span><span style="background-color:#ffffff;font-size:11pt;">Record&aacute; que la&nbsp;</span><strong><span style="background-color:#ffffff;font-size:11pt;">firma debe ser manuscrita</span></strong><span style="background-color:#ffffff;font-size:11pt;">, es decir, escrita o garabateada a mano.</span></p><br><p style="text-align: center;"><span style="background-color:#ffffff;font-size:11pt;">Ten&eacute;s 7 d&iacute;as m&aacute;s para enviar la documentaci&oacute;n o perder&aacute;s la vacante.&nbsp;</span></p><p style="text-align: center;"><span style="background-color:#ffffff;font-size:11pt;">&iexcl;No te cuelgues! &iexcl;Queremos encontrarnos en el aula con vos!&nbsp;</span></p><p>--</p></div><div style="text-align: start;color: rgb(34, 34, 34);background-color: rgb(255, 255, 255);font-size: small;"><strong><img width="96" height="31" src="https://ci3.googleusercontent.com/mail-sig/AIorK4wTa9xs-F8lNN0rtQlQZz9zT7Fy4tyJw11JFiLolXbD43-TOdy4vIS646WAToLBk4UaLYNWhjo"><br></strong></div><div style="text-align: start;color: rgb(34, 34, 34);background-color: rgb(255, 255, 255);font-size: small;"><strong>{tu_nombre.value} {tu_apellido.value}</strong></div><div style="text-align: start;color: rgb(34, 34, 34);background-color: rgb(255, 255, 255);font-size: small;">{rol.value} | Aprende Programando&nbsp;</div><div style="text-align: start;color: rgb(34, 34, 34);background-color: rgb(255, 255, 255);font-size: small;"><span style="color: rgb(0, 0, 0);font-size: 12.8px;">Agencia de Aprendizaje a lo Largo de la Vida&nbsp;|</span></div><div style="text-align: start;color: rgb(34, 34, 34);background-color: rgb(255, 255, 255);font-size: small;">Ministerio de Educaci&oacute;n - GCABA | Calle 10 y Perette. Piso 5. 5125.</div><div style="text-align: start;color: rgb(34, 34, 34);background-color: rgb(255, 255, 255);font-size: small;"><div style="color: rgb(34, 34, 34);"><div style="color: rgb(80, 0, 80);"><div style="color: rgb(34, 34, 34);"><div style="font-size: 12.8px;"><br></div></div></div></div></div></div></div>'
                        yag = yagmail.SMTP(user=f'{tb1.value}',password=f'{tb2.value}')
                        destinos = [email, emailRes]
                        asunto = f'RECORDATORIO DOCUMENTACIÓN -{nombre} ¡No pierdas tu vacante!  | Aprendé Programando 🚀'
                        yag.send(destinos,asunto,html)
                        time.sleep(3)
                        bd['estado'] = 'enviado'
                    bd.to_excel('excel/archivo_excel.xlsx', index=False)
                    snd = Container(
                            Text('Enviado ✓'),
                            padding=13,
                            border_radius=10,
                            bgcolor= colors.ORANGE_100
                            )
                    page.add(Row([snd,ElevatedButton('Otro',on_click=button_clicked)]))
                    page.update()
                enviar()
            def record_doc(e):
                
                page.add(
                    Row(
                        wrap=True,controls=[
                        Container(
                            content= tu_nombre,
                            margin=10,
                            padding=3,
                            alignment=ft.alignment.center,
                            bgcolor=ft.colors.ORANGE_100,
                            width=350,
                            height=60,
                            border_radius=10,),
                        Container(
                            content= tu_apellido,
                            margin=10,
                            padding=3,
                            alignment=ft.alignment.center,
                            bgcolor=ft.colors.ORANGE_100,
                            width=350,
                            height=60,
                            border_radius=10,),
                        Container(
                            content= rol,
                            margin=10,
                            padding=3,
                            alignment=ft.alignment.center,
                            bgcolor=ft.colors.ORANGE_100,
                            width=350,
                            height=60,
                            border_radius=10,),
                        Container(
                            content=curso,
                            margin=10,
                            padding=3,
                            alignment=ft.alignment.center,
                            bgcolor=ft.colors.ORANGE_100,
                            width=350,
                            height=60,
                            border_radius=10,),
                        Container(
                            content= dia,
                            margin=10,
                            padding=3,
                            alignment=ft.alignment.center,
                            bgcolor=ft.colors.ORANGE_100,
                            width=350,
                            height=60,
                            border_radius=10,),
                        Container(
                            content=horario,
                            margin=10,
                            padding=3,
                            alignment=ft.alignment.center,
                            bgcolor=ft.colors.ORANGE_100,
                            width=350,
                            height=60,
                            border_radius=10,)
                    ]),
                    ElevatedButton('Enviar',on_click=enviar_recordar),
                )
                page.update()
            def enviar_confirmar(e):
                def enviar():
                    for nombre, email, emailRes in zip(bd['nombre'],bd['email'],bd['emailRes']):
                        html=  f'<div style="color: rgb(80, 0, 80);"><div style="color: rgb(34, 34, 34);"><div style="font-size: 12.8px;"><center><p><span style="font-size:11pt;"><span style="border:none;"><img src="https://lh7-us.googleusercontent.com/DrZEhga3yuvqds4blIKtowVfn7uATYBT5OEuUAmvsBh1TkXx8I-sbBcN31W9_CpgREKaJalrDbkTImSAPVH19fSQ3P_a7CaYPFXqUrSXC7oOUqNXr6s8lGpNUNiBug6Vys5oGtWwtDKvt3hua4FvhHM" width="602" height="145"></span></span></p></center><p style="text-align: center;"><span style="font-size:11pt;">&iexcl;Hola {nombre}!</span></p><p style="text-align: center;"><span style="font-size:11pt;">Te confirmo la recepci&oacute;n de la documentaci&oacute;n ✅</span></p><p style="text-align: center;"><span style="color:#202124;background-color:#ffffff;font-size:11pt;"><span style="border:none;"><img alt="💡" src="https://lh7-us.googleusercontent.com/KGODRv8xWlqYVJVyfc3W_G2a4gO6mzDn15wzWYiVK_zjVcz36z6wLg2zLxILMYjNUafiqpgmIaJSdsn9m2QG9YidornsuxqKuSezZRzfkXge9yqdP4UHjlVMJgoGIPIpri6TJDoQOCnCkN8yzBG2IgU" width="17" height="17"></span></span><span style="color:#1f1f1f;background-color:#ffffff;font-size:16.5pt;">&nbsp;</span><span style="font-size:11pt;">Record&aacute; que nos vamos a encontrar los d&iacute;as&nbsp; {dia.value} de {horario.value}.</span><span style="font-size:11pt;">&nbsp;para aprender mucho sobre &nbsp; {curso.value}</span><span style="font-size:11pt;">&nbsp;</span></p><p><strong><span style="color:#ff0000;font-size:11pt;">Si todav&iacute;a no enviaste la autorizaci&oacute;n de participaci&oacute;n y difusi&oacute;n de imagen, record&aacute; que ten&eacute;s hasta la primera semana de clase para hacerlo.&nbsp;</span></strong></p><p style="text-align: center;"><span style="font-size:11pt;"><span style="border:none;"><img alt="📆" src="https://lh7-us.googleusercontent.com/lMLF-Vy3Mv2hdKjsKeDxg8spk1zWgJDyxolorl0AThnsh_LveXItU52lbaVLThur76ZxoXMx12Tsx1pDOGAwC3On5hyOqcyEqy6dhKbmo2oZxKf3DprS10Xar2n1MsasAOKjZUTW0suFNujmY6gR9Lc" width="17" height="17"></span></span><span style="font-size:11pt;">&nbsp;El&nbsp; {fecha_inicio.value}</span><span style="font-size:11pt;">&nbsp;te voy a estar enviando el link de la clase para que puedas conectarte.</span></p><br/><p><span style="font-size:11pt;">📩 Vamos a comunicarnos por un canal de&nbsp;</span><strong><span style="font-size:11pt;">Discord</span></strong><span style="font-size:11pt;">.&nbsp;</span></p><ul><li style="list-style-type:disc;font-size:11pt;"><p><span style="font-size:11pt;">Pod&eacute;s descargarlo haciendo click aqu&iacute;:&nbsp;</span><a href="https://discord.com/."><u><span style="color:#1155cc;font-size:11pt;">https://discord.com/.&nbsp;</span></u></a></p></li><li style="list-style-type:disc;font-size:11pt;"><p><span style="font-size:11pt;">Tambi&eacute;n pod&eacute;s utilizarlo desde la p&aacute;gina web sin tener que descargarlo&nbsp;</span></p></li><li style="list-style-type:disc;font-size:11pt;"><p><span style="font-size:11pt;">O lo pod&eacute;s bajar en tu celular dentro de la &ldquo;</span><a href="https://play.google.com/store/apps/details?id=com.discord&hl=es_AR&gl=US"><u><span style="color:#1155cc;font-size:11pt;">Play Store</span></u></a><span style="font-size:11pt;">&rdquo; (Android) o &ldquo;</span><a href="https://apps.apple.com/cl/app/discord-chatea-habla-y-une/id985746746"><u><span style="color:#1155cc;font-size:11pt;">App Store</span></u></a><span style="font-size:11pt;">&rdquo; (iOS).</span></p></li></ul><br/><p><span style="font-size:11pt;">📢 La invitaci&oacute;n al canal es la siguiente:&nbsp; {link_discord.value} </span></p><br/><p><strong><span style="font-size:11pt;">👉 CAMBIO DE APODO EN EL SERVIDOR (OBLIGATORIO)&nbsp;</span></strong></p><p><span style="font-size:11pt;">Es&nbsp;</span><strong><span style="font-size:11pt;">muy importante</span></strong><span style="font-size:11pt;">&nbsp;que tu&nbsp;</span><strong><span style="font-size:11pt;">nombre de usuario</span></strong><span style="font-size:11pt;">&nbsp;dentro del servidor sea el&nbsp;</span><strong><span style="font-size:11pt;">mismo con el cual te inscribiste al programa.&nbsp;</span></strong><span style="font-size:11pt;">Para eso, ten&eacute;s que clickear en el nombre del servidor (arriba a la izquierda) &lt; Editar Perfil del Servidor (Edit Server Profile) y completar el nombre de usuario con lo que corresponda.</span></p><p><span style="font-size:11pt;">📌 Te dejo algunos videos tutoriales por si ten&eacute;s dudas al momento de ingresar a&nbsp;</span><strong><span style="font-size:11pt;">Discord</span></strong><span style="font-size:11pt;">&nbsp;por primera vez:</span></p><ul><li style="list-style-type:disc;font-size:11pt;"><p><a href="https://youtu.be/DfdmehAjU7A"><u><span style="color:#1155cc;font-size:11pt;">C&oacute;mo crear tu cuenta desde una computadora</span></u></a></p></li><li style="list-style-type:disc;font-size:11pt;"><p><a href="https://youtu.be/syIVUcwBfdc"><u><span style="color:#1155cc;font-size:11pt;">C&oacute;mo crear tu cuenta desde un celular</span></u></a></p></li><li style="list-style-type:disc;font-size:11pt;"><p><a href="https://youtu.be/zEth97BOfPs"><u><span style="color:#1155cc;font-size:11pt;">C&oacute;mo unirse a un servidor</span></u></a></p></li><li style="list-style-type:disc;font-size:11pt;"><p><a href="https://youtu.be/JZJbYPub49k"><u><span style="color:#1155cc;font-size:11pt;">C&oacute;mo cambiar el apodo en un servidor</span></u></a></p></li></ul><br/><p style="text-align: center;"><span style="font-size:11pt;"><span style="border:none;"><img alt="🙋" src="https://lh7-us.googleusercontent.com/I_ELjNW2tCo3ynFEcutCI3vIgQPu9zXPEvH3sXaC_Wp6J6OdVAry0YuhSJu_b6cPl340eb58RjTspJFWoMxNge4c5BzJGz5CqoR5phMqVJ5iYXVWSpZv13hGaBM1BrCKoh2yxrUG8pZtXcoFhHg7fYE" width="17" height="17"></span></span><span style="font-size:11pt;">&nbsp;Si ten&eacute;s alg&uacute;n inconveniente, no dudes en escribirme.</span></p><p style="text-align: left; font-size: 12.8px;">--</p></div><div style="text-align: start;color: rgb(34, 34, 34);background-color: rgb(255, 255, 255);font-size: small;"><strong><img width="96" height="31" src="https://ci3.googleusercontent.com/mail-sig/AIorK4wTa9xs-F8lNN0rtQlQZz9zT7Fy4tyJw11JFiLolXbD43-TOdy4vIS646WAToLBk4UaLYNWhjo"><br></strong></div><div style="text-align: start;color: rgb(34, 34, 34);background-color: rgb(255, 255, 255);font-size: small;"><strong>{tu_nombre.value} {tu_apellido.value}</strong></div><div style="text-align: start;color: rgb(34, 34, 34);background-color: rgb(255, 255, 255);font-size: small;">{rol.value} | Aprende Programando&nbsp;</div><div style="text-align: start;color: rgb(34, 34, 34);background-color: rgb(255, 255, 255);font-size: small;"><span style="color: rgb(0, 0, 0);font-size: 12.8px;">Agencia de Aprendizaje a lo Largo de la Vida</span><span style="color: rgb(0, 0, 0);font-size: 12.8px;">&nbsp;|</span></div><div style="text-align: start;color: rgb(34, 34, 34);background-color: rgb(255, 255, 255);font-size: small;">Ministerio de Educaci&oacute;n - GCABA | Calle 10 y Perette. Piso 5. 5125.</div><div style="text-align: start;color: rgb(34, 34, 34);background-color: rgb(255, 255, 255);font-size: small;"><div style="color: rgb(34, 34, 34);"><div style="color: rgb(80, 0, 80);"><div style="color: rgb(34, 34, 34);"><div style="font-size: 12.8px;"><br></div></div></div></div></div></div></div>'
                        yag = yagmail.SMTP(user=f'{tb1.value}',password=f'{tb2.value}')
                        destinos = [email, emailRes]
                        asunto = f'💡{nombre} EMPECEMOS A CONECTARNOS | Aprendé Programando 🚀'
                        yag.send(destinos,asunto,html)
                        time.sleep(3)
                        bd['estado'] = 'enviado'
                    bd.to_excel('excel/archivo_excel.xlsx', index=False)
                    snd = Container(
                            Text('Enviado ✓'),
                            padding=13,
                            border_radius=10,
                            bgcolor= colors.ORANGE_100
                            )
                    page.add(Row([snd,ElevatedButton('Otro',on_click=button_clicked)]))
                    page.update()
                enviar()
            def confirmado(e):
                page.add(
                    Row(
                        wrap=True,controls=[
                        Container(
                            content= tu_nombre,
                            margin=10,
                            padding=3,
                            alignment=ft.alignment.center,
                            bgcolor=ft.colors.ORANGE_100,
                            width=350,
                            height=60,
                            border_radius=10,),
                        Container(
                            content= tu_apellido,
                            margin=10,
                            padding=3,
                            alignment=ft.alignment.center,
                            bgcolor=ft.colors.ORANGE_100,
                            width=350,
                            height=60,
                            border_radius=10,),
                        Container(
                            content= rol,
                            margin=10,
                            padding=3,
                            alignment=ft.alignment.center,
                            bgcolor=ft.colors.ORANGE_100,
                            width=350,
                            height=60,
                            border_radius=10,),
                        Container(
                            content=curso,
                            margin=10,
                            padding=3,
                            alignment=ft.alignment.center,
                            bgcolor=ft.colors.ORANGE_100,
                            width=350,
                            height=60,
                            border_radius=10,),
                        Container(
                            content= dia,
                            margin=10,
                            padding=3,
                            alignment=ft.alignment.center,
                            bgcolor=ft.colors.ORANGE_100,
                            width=350,
                            height=60,
                            border_radius=10,),
                        Container(
                            content=horario,
                            margin=10,
                            padding=3,
                            alignment=ft.alignment.center,
                            bgcolor=ft.colors.ORANGE_100,
                            width=350,
                            height=60,
                            border_radius=10,),
                        Container(
                            content=fecha_inicio,
                            margin=10,
                            padding=3,
                            alignment=ft.alignment.center,
                            bgcolor=ft.colors.ORANGE_100,
                            width=350,
                            height=60,
                            border_radius=10,),
                        Container(
                            content=link_discord,
                            margin=10,
                            padding=3,
                            alignment=ft.alignment.center,
                            bgcolor=ft.colors.ORANGE_100,
                            width=350,
                            height=60,
                            border_radius=10,)
                    ]),
                    ElevatedButton('Enviar',on_click=enviar_confirmar),
                )
                page.update()
            if e.files:
                file_name = "archivo_excel.xlsx"
                destination_path = os.path.join(current_directory, excel_folder, file_name)
            
            # Copiar el archivo seleccionado a la carpeta 'excel'
                with open(e.files[0].path, 'rb') as source_file, open(destination_path, 'wb') as dest_file:
                    dest_file.write(source_file.read())
                    
                
                success_text.value = Container(
                Text('Excel guardado correctamente ✓'),
                padding=13,
                border_radius=10,
                bgcolor= colors.ORANGE_100
                )
                success_text.update()
                #page.add(ElevatedButton("plantilla 1", on_click=mostrar_plantilla1))
            else:
                success_text.value = Container(
                Text('Cancelado'),
                padding=13,
                border_radius=10,
                bgcolor= colors.ORANGE_100
                )
                success_text.update()
            page.clean()
            page.add(
                btn,
                Row([
                btn2,
                success_text.value,
                ElevatedButton("Ver datos", on_click=open_dlg),
                ]),
                Row([
                    Card(
                content=ft.Container(
                  content=ft.Column([
                    ft.ListTile(
                    leading=ft.Icon(ft.icons.ATTACH_EMAIL),
                    title=ft.Text("Pedido de documentación"),
                    subtitle=ft.Text(
                    "Solicitud de documentación requerida (primer correo)."
                    ),),
                    ft.Row(
                    [ft.ElevatedButton("Seleccionar",on_click=confirm_doc), ft.ElevatedButton("Ver plantilla",on_click=open_dlg_recolectar)],
                    alignment=ft.MainAxisAlignment.END,
                    ),
                    ]),width=400,padding=10,
                  )),
                    Card(
                    content=ft.Container(
                    content=ft.Column([
                    ft.ListTile(
                    leading=ft.Icon(ft.icons.ATTACH_EMAIL),
                    title=ft.Text("Recordatorio de documentación"),
                    subtitle=ft.Text(
                    "Recordatorio para el envio de la documentación."
                    ),),
                    ft.Row(
                    [ElevatedButton("Seleccionar",on_click=record_doc), ElevatedButton("Ver plantilla",on_click=open_dlg_recordar)],
                    alignment=ft.MainAxisAlignment.END,
                    ),
                    ]),width=400,padding=10,
                  )),
                    Card(
                content=ft.Container(
                  content=ft.Column([
                    ft.ListTile(
                    leading=ft.Icon(ft.icons.ATTACH_EMAIL),
                    title=ft.Text("Confirmacion + invitación a discord"),
                    subtitle=ft.Text(
                    "Confirmacion de documentación recibida e invitación a discord."
                    ),),
                    ft.Row(
                    [ElevatedButton("Seleccionar",on_click=confirmado), ElevatedButton("Ver plantilla",on_click=open_dlg_confirmacion)],
                    alignment=ft.MainAxisAlignment.END,
                    ),
                    ]),width=400,padding=10,
                  )),
                ])
                )
        img_recordar = Image(
                src="img/ejemplo_excel.png",
                width=450,
                height=490,
                border_radius=10
                )
        dialog_file = FilePicker(on_result=save_excel_file_result)
        dlg_excel = AlertDialog(
                title= Text("Ordern de columnas con datos en excel"),
                bgcolor=colors.PINK_50,
                content=img_recordar,
            )
        def open_dlg_excel(e):
                page.dialog = dlg_excel
                dlg_excel.open = True
                page.update()
        text_excel = TextButton('Importante a tener en cuenta sobre odren del excel a descargar',on_click=open_dlg_excel)
        btn2 = ElevatedButton("Descargar y Guardar Excel", on_click=lambda _: dialog_file.pick_files(allowed_extensions=['xlsx', '.xls']),)
        
        page.overlay.extend([dialog_file])
        success_text = Container()
        page.add(
            btn,
            text_excel,
            btn2,
            success_text,
            )
        page.update()
#si se quiere iniciar solo en una aplicacion se hace de la siguiente manera
ft.app(target=main)
#si se quiere iniciar en una web se hace de la siguiente manera
#ft.app(target=main, view=ft.WEB_BROWSER)
